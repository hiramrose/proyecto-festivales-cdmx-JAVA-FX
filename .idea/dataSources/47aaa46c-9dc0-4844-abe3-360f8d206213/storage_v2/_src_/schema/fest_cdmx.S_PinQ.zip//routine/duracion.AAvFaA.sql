create
    definer = root@localhost function duracion(inicia date, termina date) returns int
    comment 'Cálculo de días que dura un festival'
BEGIN
DECLARE duraFest int;
SET duraFest = (SELECT CONCAT(TIMESTAMPDIFF(DAY, fecha_inicio, fecha_termino)) FROM festival WHERE fecha_inicio=inicia AND fecha_termino=termina) + 1;
RETURN duraFest;
END;

