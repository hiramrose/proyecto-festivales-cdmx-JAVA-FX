create definer = root@localhost view asistencia_extranjera as
select count(`fest_cdmx`.`asistente`.`pais`) AS `extranjeros`
from `fest_cdmx`.`asistente`
where (`fest_cdmx`.`asistente`.`pais` <> 'México');

