create definer = root@localhost view asistencia_pais as
select count(`fest_cdmx`.`asistente`.`pais`) AS `numero`, `fest_cdmx`.`asistente`.`pais` AS `pais`
from `fest_cdmx`.`asistente`
group by `fest_cdmx`.`asistente`.`pais`;

