create definer = root@localhost view directivo as
select concat(`t3`.`nombre`, ' ', `t3`.`paterno`, ' ', `t3`.`materno`) AS `personal_directivo`,
       `t1`.`cargo`                                                    AS `cargo`
from ((`fest_cdmx`.`jornada` `t1` join `fest_cdmx`.`personal` `t2` on ((`t1`.`id_jornada` = `t2`.`id_jornada_fk`)))
         join `fest_cdmx`.`usuario` `t3` on ((`t2`.`id_usuario_fk` = `t3`.`id_usuario`)))
where `t3`.`id_usuario` in (select `fest_cdmx`.`personal`.`id_usuario_fk` from `fest_cdmx`.`personal`);

