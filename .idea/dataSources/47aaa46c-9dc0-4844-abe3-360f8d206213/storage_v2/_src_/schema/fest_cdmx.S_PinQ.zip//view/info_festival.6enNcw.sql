create definer = root@localhost view info_festival as
select `t3`.`proyecto`              AS `Festival`,
       `t3`.`sede`                  AS `sede`,
       `t3`.`costo`                 AS `PrecioXBoleto`,
       `t2`.`nombre_organizacion`   AS `Patrocinador`,
       `t1`.`tipo_sector_economico` AS `Sector_Económico`
from ((`fest_cdmx`.`sector_economico` `t1` join `fest_cdmx`.`institucionalidad` `t2` on ((`t1`.`id_sector_economico` = `t2`.`id_sector_economico_fk`)))
         join `fest_cdmx`.`festival` `t3` on ((`t3`.`id_institucion_fk` = `t2`.`id_institucion`)));

