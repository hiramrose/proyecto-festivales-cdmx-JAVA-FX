create definer = root@localhost view mas_descuento as
select concat(`t4`.`nombre`, ' ', `t4`.`paterno`) AS `nombre_asistente`,
       `t3`.`pais`                                AS `pais`,
       `t2`.`id_membresia`                        AS `id_membresia`,
       `t2`.`tipo_membresia`                      AS `tipo_membresia`
from (((`fest_cdmx`.`promocion` `t1` join `fest_cdmx`.`membresia` `t2` on ((`t1`.`id_promocion` = `t2`.`id_promocion_fk`))) join `fest_cdmx`.`asistente` `t3` on ((`t2`.`id_asistente_fk` = `t3`.`id_asistente`)))
         join `fest_cdmx`.`usuario` `t4` on ((`t3`.`id_usuario_fk` = `t4`.`id_usuario`)))
where (`t2`.`id_promocion_fk` = 5);

