create definer = root@localhost view tipo_de_usuario as
select concat(`fest_cdmx`.`usuario`.`nombre`, ' ', `fest_cdmx`.`usuario`.`paterno`) AS `nombre_completo`,
       (case
            when `fest_cdmx`.`usuario`.`id_usuario` in
                 (select `fest_cdmx`.`asistente`.`id_usuario_fk` from `fest_cdmx`.`asistente`) then 'Asistente'
            when `fest_cdmx`.`usuario`.`id_usuario` in
                 (select `fest_cdmx`.`personal`.`id_usuario_fk` from `fest_cdmx`.`personal`) then 'Personal'
            when `fest_cdmx`.`usuario`.`id_usuario` in
                 (select `fest_cdmx`.`miembro_comunidad`.`id_usuario_fk` from `fest_cdmx`.`miembro_comunidad`)
                then 'Miembro de la comunidad'
            else 'No identificado' end)                                             AS `tipo_de_usuario`
from `fest_cdmx`.`usuario`;

